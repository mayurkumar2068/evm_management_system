import 'package:evm_management_system/features/presiding_concern/data/config/turnout_slot_registry.dart';
import 'package:evm_management_system/features/presiding_concern/data/constants/po_election_api_fields.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_entities.dart';

/// Maps `po-status` API payload into presiding session entities.
abstract final class PoElectionStatusMapper {
  static Map<String, TurnoutRecord> turnoutRecordsFromStatus(
    Map<String, dynamic> data,
  ) {
    final Map<String, TurnoutRecord> records = <String, TurnoutRecord>{};

    for (final TurnoutSlotConfig config
        in TurnoutSlotRegistry.genderStatusSlots()) {
      final TurnoutStatusFields? fields = config.statusFields;
      if (fields == null) continue;

      final TurnoutRecord? record = _genderRecord(
        slotId: config.slotId,
        male: _int(data[fields.male]),
        female: _int(data[fields.female]),
        other: _int(data[fields.other]),
        savedAt: _date(data[fields.updatedAt]),
      );
      if (record != null) records[config.slotId] = record;
    }

    final int? queueMale = _int(data[PoElectionResponseFields.qMale]);
    final int? queueFemale = _int(data[PoElectionResponseFields.qFemale]);
    final int? queueOther = _int(data[PoElectionResponseFields.qOther]);
    final DateTime? queueSavedAt = _date(
      data[PoElectionResponseFields.qUpdateTime],
    );
    if (queueMale != null ||
        queueFemale != null ||
        queueOther != null ||
        queueSavedAt != null) {
      records[TurnoutSlotIds.queueCount] = TurnoutRecord(
        slotId: TurnoutSlotIds.queueCount,
        queueCount: (queueMale ?? 0) + (queueFemale ?? 0) + (queueOther ?? 0),
        savedAt: queueSavedAt,
        pendingSync: false,
        isLocked: queueSavedAt != null,
      );
    }

    return records;
  }

  static List<PresidingMilestone> milestonesFromStatus({
    required List<PresidingMilestone> current,
    required Map<String, dynamic> data,
  }) {
    return current
        .map((PresidingMilestone milestone) {
          final _MilestoneStatus? status = _milestoneStatus(
            milestone.id,
            data,
            current: milestone,
          );
          if (status == null) return milestone;

          if (status.isCompleted) {
            return milestone.copyWith(
              state: PresidingMilestoneState.completed,
              completedAt: status.completedAt ?? milestone.completedAt,
              pendingSync: false,
            );
          }

          return milestone.copyWith(
            state: PresidingMilestoneState.pending,
            clearCompletedAt: true,
            pendingSync: false,
          );
        })
        .toList(growable: false);
  }

  static TurnoutRecord? _genderRecord({
    required String slotId,
    required int? male,
    required int? female,
    required int? other,
    required DateTime? savedAt,
  }) {
    if (male == null && female == null && other == null && savedAt == null) {
      return null;
    }
    // 0/0/0 with no timestamp = slot never filled on server — omit so we
    // don't overwrite good local/API counts with empty zeros.
    if (savedAt == null &&
        (male ?? 0) == 0 &&
        (female ?? 0) == 0 &&
        (other ?? 0) == 0) {
      return null;
    }
    // Live poll: backend may return timestamp with empty/null counts.
    // Treat 0/0/0 as "not submitted" so UI doesn't show a misleading time.
    if (slotId == TurnoutSlotIds.livePollInfo &&
        (male ?? 0) == 0 &&
        (female ?? 0) == 0 &&
        (other ?? 0) == 0) {
      return const TurnoutRecord(
        slotId: TurnoutSlotIds.livePollInfo,
        male: 0,
        female: 0,
        thirdGender: 0,
        savedAt: null,
        pendingSync: false,
        isLocked: false,
      );
    }

    return TurnoutRecord(
      slotId: slotId,
      male: male ?? 0,
      female: female ?? 0,
      thirdGender: other ?? 0,
      savedAt: savedAt,
      pendingSync: false,
      // Live poll remains editable during polling; it only locks on explicit
      // milestone submit (2-2 hourly/live complete), not merely on refresh.
      isLocked:
          slotId == TurnoutSlotIds.livePollInfo ? false : (savedAt != null),
    );
  }

  static _MilestoneStatus? _milestoneStatus(
    String milestoneId,
    Map<String, dynamic> data, {
    required PresidingMilestone current,
  }) {
    return switch (milestoneId) {
      PresidingMilestoneIds.leftMaterialCenter => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isDepartedFromHome]),
        completedAt: _date(data[PoElectionResponseFields.departedFromHomeTime]),
      ),
      PresidingMilestoneIds.reachedPollingStation => _MilestoneStatus(
        isCompleted: _bool(
          data[PoElectionResponseFields.isReachedToPollingStation],
        ),
        completedAt: _date(
          data[PoElectionResponseFields.reachedToPollingStationTime],
        ),
      ),
      PresidingMilestoneIds.materialReceived => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isMaterialReceived]),
        completedAt: _date(data[PoElectionResponseFields.materialReceivedTime]),
      ),
      PresidingMilestoneIds.mockPoll => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isMockPollConducted]),
        completedAt: _date(
          data[PoElectionResponseFields.mockPollConductedTime],
        ),
      ),
      PresidingMilestoneIds.pollStart => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isPollStarted]),
        completedAt: _date(data[PoElectionResponseFields.pollStartedTime]),
      ),
      PresidingMilestoneIds.twoHourlyInfo =>
        _twoHourlyStatus(data, current: current),
      PresidingMilestoneIds.livePollInfo =>
        _livePollStatus(data, current: current),
      PresidingMilestoneIds.pollEnd => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isPollEnded]),
        completedAt: _date(data[PoElectionResponseFields.pollEndedTime]),
      ),
      PresidingMilestoneIds.machineSealed => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isMachineSealed]),
        completedAt: _date(data[PoElectionResponseFields.machineSealedTime]),
      ),
      PresidingMilestoneIds.materialHandedOver => _MilestoneStatus(
        isCompleted: _bool(data[PoElectionResponseFields.isMaterialSubmitted]),
        completedAt: _date(
          data[PoElectionResponseFields.materialSubmittedTime],
        ),
      ),
      _ => null,
    };
  }

  /// Clears stale local "completed" when server has no slot times.
  /// Keeps finish-state only when local already completed + server still has
  /// turnout evidence; never invents completion from a single slot save.
  static _MilestoneStatus? _twoHourlyStatus(
    Map<String, dynamic> data, {
    required PresidingMilestone current,
  }) {
    if (!_bool(data[PoElectionResponseFields.isPollStarted])) {
      return const _MilestoneStatus(isCompleted: false);
    }

    final DateTime? latest = _latestTwoHourlyEvidenceTime(data);
    if (latest == null) {
      // Server empty ⇒ drop fake local timestamp/flag.
      return const _MilestoneStatus(isCompleted: false);
    }
    if (!current.isCompleted) {
      // Slots may exist, but finish button not pressed yet.
      return null;
    }
    return _MilestoneStatus(isCompleted: true, completedAt: latest);
  }

  /// Live uses only PollLive* fields — never copies 2–2 hourly timestamp.
  static _MilestoneStatus? _livePollStatus(
    Map<String, dynamic> data, {
    required PresidingMilestone current,
  }) {
    if (!_bool(data[PoElectionResponseFields.isPollStarted])) {
      return const _MilestoneStatus(isCompleted: false);
    }

    final int male = _int(data[PoElectionResponseFields.pollLiveMale]) ?? 0;
    final int female = _int(data[PoElectionResponseFields.pollLiveFemale]) ?? 0;
    final int other = _int(data[PoElectionResponseFields.pollLiveOther]) ?? 0;
    final DateTime? updatedAt = _date(
      data[PoElectionResponseFields.pollLiveUpdateTime],
    );

    final bool hasLiveEvidence =
        updatedAt != null && (male > 0 || female > 0 || other > 0);
    if (!hasLiveEvidence) {
      return const _MilestoneStatus(isCompleted: false);
    }
    if (!current.isCompleted) {
      return null;
    }
    return _MilestoneStatus(isCompleted: true, completedAt: updatedAt);
  }

  static DateTime? _latestTwoHourlyEvidenceTime(Map<String, dynamic> data) {
    final List<DateTime> times = <DateTime>[
      if (_date(data[PoElectionResponseFields.poll9AmUpdateTime]) != null)
        _date(data[PoElectionResponseFields.poll9AmUpdateTime])!,
      if (_date(data[PoElectionResponseFields.poll11AmUpdateTime]) != null)
        _date(data[PoElectionResponseFields.poll11AmUpdateTime])!,
      if (_date(data[PoElectionResponseFields.poll1PmUpdateTime]) != null)
        _date(data[PoElectionResponseFields.poll1PmUpdateTime])!,
      if (_date(data[PoElectionResponseFields.poll3PmUpdateTime]) != null)
        _date(data[PoElectionResponseFields.poll3PmUpdateTime])!,
      if (_date(data[PoElectionResponseFields.poll5PmUpdateTime]) != null)
        _date(data[PoElectionResponseFields.poll5PmUpdateTime])!,
      if (_date(data[PoElectionResponseFields.qUpdateTime]) != null)
        _date(data[PoElectionResponseFields.qUpdateTime])!,
      if (_date(data[PoElectionResponseFields.finalUpdateTime]) != null)
        _date(data[PoElectionResponseFields.finalUpdateTime])!,
    ];
    if (times.isEmpty) return null;
    times.sort();
    return times.last;
  }

  static int? _int(Object? value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  static DateTime? _date(Object? value) {
    if (value == null) return null;
    return DateTime.tryParse(value.toString());
  }

  static bool _bool(Object? value) {
    if (value is bool) return value;
    if (value == null) return false;
    final String normalized = value.toString().trim().toLowerCase();
    return normalized == 'true' || normalized == '1';
  }
}

final class _MilestoneStatus {
  const _MilestoneStatus({required this.isCompleted, this.completedAt});

  final bool isCompleted;
  final DateTime? completedAt;
}

import 'package:evm_management_system/core/location/location_service.dart';
import 'package:evm_management_system/core/logging/app_logger.dart';
import 'package:evm_management_system/core/network/connectivity_service.dart';
import 'package:evm_management_system/features/presiding_concern/data/models/po_election_action_result.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_action_outcome.dart';
import 'package:evm_management_system/features/presiding_concern/data/config/turnout_slot_registry.dart';
import 'package:evm_management_system/features/presiding_concern/data/datasource/presiding_concern_local_datasource.dart';
import 'package:evm_management_system/features/presiding_concern/data/datasource/presiding_concern_remote_datasource.dart';
import 'package:evm_management_system/features/presiding_concern/data/datasource/presiding_election_context_store.dart';
import 'package:evm_management_system/features/presiding_concern/data/models/po_election_api_mapper.dart';
import 'package:evm_management_system/features/presiding_concern/data/models/po_election_status_mapper.dart';
import 'package:evm_management_system/features/presiding_concern/data/models/presiding_session_mapper.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_election_context.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_entities.dart';
import 'package:evm_management_system/features/presiding_concern/domain/repository/presiding_concern_repository.dart';
import 'package:evm_management_system/features/presiding_concern/domain/turnout_count_validator.dart';

/// API-first repository for PO election-day data (local cache only when offline).
final class PresidingConcernRepositoryImpl
    implements PresidingConcernRepository {
  PresidingConcernRepositoryImpl({
    required PresidingConcernLocalDatasource local,
    required PresidingElectionContextStore contextStore,
    required ConnectivityService connectivity,
    PresidingConcernRemoteDatasource? remote,
    LocationService? locationService,
  }) : _local = local,
       _contextStore = contextStore,
       _connectivity = connectivity,
       _remote = remote,
       _locationService = locationService ?? LocationService();

  final PresidingConcernLocalDatasource _local;
  final PresidingElectionContextStore _contextStore;
  final ConnectivityService _connectivity;
  final PresidingConcernRemoteDatasource? _remote;
  final LocationService _locationService;

  @override
  Future<PresidingSession> loadSession() async {
    final PresidingElectionContext? context = await _contextStore.read();
    final Map<String, dynamic>? raw = await _local.readSession();
    if (raw == null) {
      final PresidingSession seeded = _seedSession(context);
      await _persist(seeded);
      return seeded;
    }
    final PresidingSession parsed = PresidingSessionMapper.fromJson(raw);
    final PresidingSession session = _ensureMilestoneCatalog(
      _mergeContext(parsed, context),
    );
    if (context != null &&
        (session.electionId != parsed.electionId ||
            session.psId != parsed.psId ||
            session.areaType != parsed.areaType ||
            session.pollingStationCode != parsed.pollingStationCode)) {
      await _persist(session);
    }
    return session;
  }

  @override
  Future<PresidingActionOutcome> completeMilestone(String milestoneId) async {
    final PresidingSession session = await loadSession();
    final PresidingMilestone milestone = session.milestones.firstWhere(
      (PresidingMilestone m) => m.id == milestoneId,
    );
    if (milestone.isCompleted) {
      return PresidingActionOutcome(session: session);
    }
    if (!session.isMilestoneActionEnabled(milestoneId)) {
      return PresidingActionOutcome(
        session: session,
        message: session.milestoneActionBlockKey(milestoneId),
      );
    }

    final PoElectionActionResult apiResult = await _syncMilestone(
      session: session,
      milestoneId: milestoneId,
    );
    final bool synced = apiResult.accepted;
    // Prefer server ActionDateTime. If already-registered with no timestamp,
    // do NOT invent simulator clock — UI shows completed without a fake time.
    DateTime? completedAt = apiResult.actionDateTime ??
        (apiResult.alreadyRegistered
            ? null
            : (synced ? DateTime.now() : DateTime.now()));

    // 2–2 hourly / live: use their own evidence times (never share one clock).
    if (milestoneId == PresidingMilestoneIds.twoHourlyInfo) {
      completedAt = _latestLocalTurnoutTime(session) ?? completedAt;
    } else if (milestoneId == PresidingMilestoneIds.livePollInfo) {
      final TurnoutRecord? live =
          session.turnoutRecords[TurnoutSlotIds.livePollInfo];
      final bool hasLiveCounts = (live?.male ?? 0) > 0 ||
          (live?.female ?? 0) > 0 ||
          (live?.thirdGender ?? 0) > 0;
      completedAt = hasLiveCounts ? (live?.savedAt ?? completedAt) : null;
    }

    final List<PresidingMilestone> updated = session.milestones
        .map((PresidingMilestone item) {
          if (item.id != milestoneId) return item;
          if (completedAt == null &&
              (apiResult.alreadyRegistered ||
                  milestoneId == PresidingMilestoneIds.livePollInfo)) {
            return item.copyWith(
              state: PresidingMilestoneState.completed,
              clearCompletedAt: true,
              pendingSync: false,
            );
          }
          return item.copyWith(
            state: PresidingMilestoneState.completed,
            completedAt: completedAt ?? DateTime.now(),
            pendingSync: !synced,
          );
        })
        .toList(growable: false);

    Map<String, TurnoutRecord> turnout = session.turnoutRecords;
    // Submitting 2–2 hourly (or locking live) freezes live जानकारी edits.
    if (milestoneId == PresidingMilestoneIds.twoHourlyInfo ||
        milestoneId == PresidingMilestoneIds.livePollInfo) {
      final TurnoutRecord? live =
          turnout[TurnoutSlotIds.livePollInfo];
      if (live != null && !live.isLocked) {
        turnout = Map<String, TurnoutRecord>.from(turnout)
          ..[TurnoutSlotIds.livePollInfo] = live.copyWith(isLocked: true);
      } else if (live == null) {
        turnout = Map<String, TurnoutRecord>.from(turnout)
          ..[TurnoutSlotIds.livePollInfo] = const TurnoutRecord(
            slotId: TurnoutSlotIds.livePollInfo,
            isLocked: true,
          );
      }
    }

    final PresidingSession next = session.copyWith(
      milestones: updated,
      turnoutRecords: turnout,
    );
    await _persist(next);
    return PresidingActionOutcome(
      session: next,
      alreadyRegistered: apiResult.alreadyRegistered,
      message: apiResult.message,
    );
  }

  @override
  Future<PresidingSession> saveTurnout({
    required String slotId,
    int? male,
    int? female,
    int? thirdGender,
    int? queueCount,
  }) async {
    final PresidingSession session = await loadSession();
    final TurnoutRecord? existing = session.turnoutRecords[slotId];
    if (existing?.isReadOnly ?? false) {
      return session;
    }

    final bool isQueueOnly = slotId == TurnoutSlotIds.queueCount;
    final PresidingElectionContext? electors = await _contextStore.read();
    final int resolvedMale = male ?? existing?.male ?? 0;
    final int resolvedFemale = female ?? existing?.female ?? 0;
    final int resolvedOther = thirdGender ?? existing?.thirdGender ?? 0;
    final int resolvedQueue = queueCount ?? existing?.queueCount ?? 0;

    if (isQueueOnly) {
      if (resolvedQueue < 0) {
        throw const TurnoutCountValidationException(
          TurnoutCountValidationResult.fail(
            'presiding.count_cannot_be_negative',
          ),
        );
      }
      if (resolvedQueue > TurnoutCountValidator.maxEnterableCount) {
        throw const TurnoutCountValidationException(
          TurnoutCountValidationResult.fail(
            'presiding.count_max_four_digits',
            limit: TurnoutCountValidator.maxEnterableCount,
          ),
        );
      }
    } else {
      final TurnoutCountValidationResult validation =
          TurnoutCountValidator.validate(
        male: resolvedMale,
        female: resolvedFemale,
        other: resolvedOther,
        bounds: TurnoutCountValidator.boundsFor(
          session: session,
          slotId: slotId,
          electors: electors,
        ),
      );
      if (!validation.isOk) {
        throw TurnoutCountValidationException(validation);
      }
    }

    final TurnoutCountValidationResult lastPlusQueue =
        TurnoutCountValidator.validateLastPlusQueueVsCompletion(
      session: session,
      slotId: slotId,
      male: resolvedMale,
      female: resolvedFemale,
      other: resolvedOther,
      queueCount: resolvedQueue,
    );
    if (!lastPlusQueue.isOk) {
      throw TurnoutCountValidationException(lastPlusQueue);
    }

    final TurnoutRecord record = TurnoutRecord(
      slotId: slotId,
      male: male ?? existing?.male,
      female: female ?? existing?.female,
      thirdGender: thirdGender ?? existing?.thirdGender,
      queueCount: queueCount ?? existing?.queueCount,
      savedAt: DateTime.now(),
      pendingSync: true,
    );

    final PoElectionActionResult apiResult = await _syncTurnout(
      session: session,
      record: record,
    );
    final DateTime savedAt = apiResult.actionDateTime ?? record.savedAt!;
    final bool lockSlot = slotId != TurnoutSlotIds.livePollInfo;
    final TurnoutRecord persisted = record.copyWith(
      savedAt: savedAt,
      pendingSync: !apiResult.accepted,
      isLocked: lockSlot,
    );

    final Map<String, TurnoutRecord> turnout = Map<String, TurnoutRecord>.from(
      session.turnoutRecords,
    )..[slotId] = persisted;
    final PresidingSession next = session.copyWith(turnoutRecords: turnout);
    await _persist(next);
    return next;
  }

  @override
  Future<void> syncPending() async {
    if (await _activeRemote() == null) return;

    PresidingSession session = await loadSession();
    bool changed = false;

    for (final PresidingMilestone milestone in session.milestones) {
      if (!milestone.pendingSync || !milestone.isCompleted) continue;
      final PoElectionActionResult apiResult = await _syncMilestone(
        session: session,
        milestoneId: milestone.id,
      );
      if (!apiResult.accepted) continue;
      changed = true;
      session = session.copyWith(
        milestones: session.milestones
            .map((PresidingMilestone item) {
              if (item.id != milestone.id) return item;
              return item.copyWith(pendingSync: false);
            })
            .toList(growable: false),
      );
    }

    for (final MapEntry<String, TurnoutRecord> entry
        in session.turnoutRecords.entries) {
      final TurnoutRecord record = entry.value;
      if (!record.pendingSync || record.savedAt == null) continue;
      final PoElectionActionResult apiResult = await _syncTurnout(
        session: session,
        record: record,
      );
      if (!apiResult.accepted) continue;
      changed = true;
      final Map<String, TurnoutRecord> turnout =
          Map<String, TurnoutRecord>.from(session.turnoutRecords)
            ..[entry.key] = record.copyWith(
              pendingSync: false,
              isLocked: entry.key == TurnoutSlotIds.livePollInfo
                  ? record.isLocked
                  : (apiResult.alreadyRegistered || apiResult.success),
            );
      session = session.copyWith(turnoutRecords: turnout);
    }

    if (changed) {
      await _persist(session);
    }
  }

  @override
  Future<PresidingSession> refreshFromServer() async {
    final PresidingConcernRemoteDatasource? remote = await _activeRemote();
    if (remote == null) return loadSession();

    final PresidingSession session = await loadSession();
    final PresidingElectionContext? context = await _resolveContext(session);
    if (context == null) return session;

    try {
      final Map<String, dynamic>? status = await remote.fetchPoStatus(
        electionId: context.electionId,
        psId: context.psId,
      );
      if (status == null || status.isEmpty) return session;

      final Map<String, TurnoutRecord> serverTurnout =
          PoElectionStatusMapper.turnoutRecordsFromStatus(status);
      // API-first: drop local slot copies the server no longer has.
      final Map<String, TurnoutRecord> mergedTurnout =
          Map<String, TurnoutRecord>.from(session.turnoutRecords);
      for (final TurnoutSlotConfig config
          in TurnoutSlotRegistry.genderStatusSlots()) {
        if (serverTurnout.containsKey(config.slotId)) {
          mergedTurnout[config.slotId] = serverTurnout[config.slotId]!;
        } else {
          mergedTurnout.remove(config.slotId);
        }
      }
      if (serverTurnout.containsKey(TurnoutSlotIds.queueCount)) {
        mergedTurnout[TurnoutSlotIds.queueCount] =
            serverTurnout[TurnoutSlotIds.queueCount]!;
      } else {
        mergedTurnout.remove(TurnoutSlotIds.queueCount);
      }
      final List<PresidingMilestone> mergedMilestones =
          PoElectionStatusMapper.milestonesFromStatus(
        current: session.milestones,
        data: status,
      );
      final PresidingSession next = session.copyWith(
        milestones: mergedMilestones,
        turnoutRecords: mergedTurnout,
      );
      await _persist(next);
      return next;
    } catch (e, s) {
      AppLogger.w('PO status refresh failed', error: e, stackTrace: s);
      return session;
    }
  }

  @override
  Future<void> applyElectionContext(PresidingElectionContext context) async {
    await _contextStore.save(context);
    final PresidingSession current = await loadSession();
    final PresidingSession next = current.copyWith(
      electionId: context.electionId,
      psId: context.psId,
      areaType: context.areaType,
      pollingStationCode:
          context.pollingStationCode ?? current.pollingStationCode,
      pollingStationName: context.pollingStationName?.isNotEmpty ?? false
          ? context.pollingStationName!
          : current.pollingStationName,
    );
    await _persist(next);
  }

  @override
  Future<void> clearLocalCache() async {
    await _local.clearSession();
    AppLogger.i('PO local session cache cleared');
  }

  @override
  Stream<PresidingSession> watchSession() async* {
    yield await loadSession();
    await for (final List<Map<String, dynamic>> _ in _local.watchAll()) {
      yield await loadSession();
    }
  }

  PresidingSession _seedSession(PresidingElectionContext? context) {
    return PresidingSession(
      electionId: context?.electionId,
      psId: context?.psId,
      areaType: context?.areaType,
      pollingStationCode: context?.pollingStationCode ?? '',
      pollingStationName: context?.pollingStationName?.isNotEmpty ?? false
          ? context!.pollingStationName!
          : PresidingDefaults.stationNameKey,
      milestones: PresidingSessionMapper.defaultMilestones(),
      turnoutRecords: <String, TurnoutRecord>{},
    );
  }

  PresidingSession _mergeContext(
    PresidingSession session,
    PresidingElectionContext? context,
  ) {
    if (context == null) return session;
    // Login context is source of truth for election identity / urban-rural.
    final String? contextArea =
        context.areaType.isNotEmpty ? context.areaType : null;
    return session.copyWith(
      electionId: context.electionId > 0
          ? context.electionId
          : session.electionId,
      psId: context.psId.isNotEmpty ? context.psId : session.psId,
      areaType: contextArea ?? session.areaType,
      pollingStationCode: context.pollingStationCode?.isNotEmpty ?? false
          ? context.pollingStationCode!
          : session.pollingStationCode,
      pollingStationName: context.pollingStationName?.isNotEmpty ?? false
          ? context.pollingStationName!
          : session.pollingStationName,
    );
  }

  Future<PoElectionActionResult> _syncMilestone({
    required PresidingSession session,
    required String milestoneId,
  }) async {
    final PresidingConcernRemoteDatasource? remote = await _activeRemote();
    if (remote == null) {
      AppLogger.i(
        'PO Election milestone skipped ($milestoneId): '
        '${await _remoteSkipReason()}',
      );
      return const PoElectionActionResult(success: false);
    }

    final PresidingElectionContext? context = await _resolveContext(session);
    if (context == null) {
      AppLogger.w(
        'PO Election milestone skipped ($milestoneId): '
        'election context missing (need electionId + psId + areaType from login)',
      );
      return const PoElectionActionResult(success: false);
    }

    final String? endpoint = PoElectionApiMapper.milestoneEndpoint(milestoneId);
    final GeoCoordinates? coords = await _locationService
        .getCurrentCoordinates();
    final Map<String, dynamic>? body = PoElectionApiMapper.milestoneBody(
      context: context,
      milestoneId: milestoneId,
      lat: coords?.latitude,
      long: coords?.longitude,
    );
    if (endpoint == null || body == null) {
      AppLogger.d(
        'PO Election milestone local-only ($milestoneId): no API mapping',
      );
      return const PoElectionActionResult(success: true);
    }

    try {
      return await remote.postAction(endpoint: endpoint, body: body);
    } catch (e, s) {
      AppLogger.w(
        'Milestone sync failed ($milestoneId)',
        error: e,
        stackTrace: s,
      );
      return const PoElectionActionResult(success: false);
    }
  }

  Future<PoElectionActionResult> _syncTurnout({
    required PresidingSession session,
    required TurnoutRecord record,
  }) async {
    final PresidingConcernRemoteDatasource? remote = await _activeRemote();
    if (remote == null) {
      AppLogger.i(
        'PO Election turnout skipped (${record.slotId}): '
        '${await _remoteSkipReason()}',
      );
      return const PoElectionActionResult(success: false);
    }

    final PresidingElectionContext? context = await _resolveContext(session);
    if (context == null) {
      AppLogger.w(
        'PO Election turnout skipped (${record.slotId}): '
        'election context missing (need electionId + psId + areaType from login)',
      );
      return const PoElectionActionResult(success: false);
    }

    final GeoCoordinates? coords = await _locationService
        .getCurrentCoordinates();
    final String endpoint = PoElectionApiMapper.turnoutEndpoint(record.slotId);
    final Map<String, dynamic>? body = PoElectionApiMapper.turnoutBody(
      context: context,
      record: record,
      lat: coords?.latitude,
      long: coords?.longitude,
    );
    if (body == null) {
      return const PoElectionActionResult(success: true);
    }

    try {
      return await remote.postAction(endpoint: endpoint, body: body);
    } catch (e, s) {
      AppLogger.w(
        'Turnout sync failed (${record.slotId})',
        error: e,
        stackTrace: s,
      );
      return const PoElectionActionResult(success: false);
    }
  }

  Future<PresidingElectionContext?> _resolveContext(
    PresidingSession session,
  ) async {
    final PresidingElectionContext? stored = await _contextStore.read();
    if (session.hasElectionContext) {
      return PresidingElectionContext(
        electionId: session.electionId!,
        psId: session.psId!,
        areaType: session.areaType!,
        pollingStationCode: session.pollingStationCode,
        pollingStationName: session.pollingStationName,
        userId: stored?.userId,
        boothLat: stored?.boothLat,
        boothLong: stored?.boothLong,
        maleElectors: stored?.maleElectors,
        femaleElectors: stored?.femaleElectors,
        otherElectors: stored?.otherElectors,
        totalElectors: stored?.totalElectors,
      );
    }
    return stored;
  }

  PresidingSession _ensureMilestoneCatalog(PresidingSession session) {
    final List<PresidingMilestone> source = session.milestones;
    final Map<String, PresidingMilestone> byId = <String, PresidingMilestone>{
      for (final PresidingMilestone m in source) m.id: m,
    };

    final PresidingMilestone existing =
        byId[PresidingMilestoneIds.materialReceived] ??
        const PresidingMilestone(
          id: PresidingMilestoneIds.materialReceived,
          sectionId: PresidingSectionIds.arrival,
          labelKey: PresidingMilestoneLabelKeys.materialReceived,
          state: PresidingMilestoneState.pending,
        );
    final PresidingMilestone material = PresidingMilestone(
      id: existing.id,
      sectionId: PresidingSectionIds.arrival,
      labelKey: PresidingMilestoneLabelKeys.materialReceived,
      state: existing.state,
      completedAt: existing.completedAt,
      opensTurnout: existing.opensTurnout,
      pendingSync: existing.pendingSync,
    );

    final List<PresidingMilestone> ordered = <PresidingMilestone>[];
    bool insertedMaterial = false;
    for (final PresidingMilestone milestone in source) {
      if (milestone.id == PresidingMilestoneIds.materialReceived) {
        continue;
      }
      if (milestone.id == PresidingMilestoneIds.reachedPollingStation &&
          !insertedMaterial) {
        ordered.add(material);
        insertedMaterial = true;
      }
      ordered.add(milestone);
    }
    if (!insertedMaterial) {
      final int leftIndex = ordered.indexWhere(
        (PresidingMilestone m) =>
            m.id == PresidingMilestoneIds.leftMaterialCenter,
      );
      if (leftIndex >= 0) {
        ordered.insert(leftIndex + 1, material);
      } else {
        ordered.insert(0, material);
      }
    }

    final bool sameOrder = ordered.length == source.length &&
        List<int>.generate(ordered.length, (int i) => i).every(
          (int i) =>
              ordered[i].id == source[i].id &&
              ordered[i].sectionId == source[i].sectionId,
        );
    return sameOrder ? session : session.copyWith(milestones: ordered);
  }

  Future<PresidingConcernRemoteDatasource?> _activeRemote() async {
    if (_remote == null) return null;
    if (!await _connectivity.isOnline) return null;
    return _remote;
  }

  Future<String> _remoteSkipReason() async {
    if (_remote == null) return 'remote datasource not configured';
    if (!await _connectivity.isOnline) return 'device offline';
    return 'unknown';
  }

  Future<void> _persist(PresidingSession session) {
    return _local.writeSession(PresidingSessionMapper.toJson(session));
  }

  DateTime? _latestLocalTurnoutTime(PresidingSession session) {
    DateTime? latest;
    for (final MapEntry<String, TurnoutRecord> entry
        in session.turnoutRecords.entries) {
      if (entry.key == TurnoutSlotIds.livePollInfo) continue;
      final DateTime? savedAt = entry.value.savedAt;
      if (savedAt == null) continue;
      if (latest == null || savedAt.isAfter(latest)) {
        latest = savedAt;
      }
    }
    return latest;
  }
}

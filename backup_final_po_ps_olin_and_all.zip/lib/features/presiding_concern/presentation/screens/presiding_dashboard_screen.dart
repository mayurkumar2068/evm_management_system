import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:evm_management_system/app/router/app_routes.dart';
import 'package:evm_management_system/design_system/mpsec/mpsec_design_system.dart';
import 'package:evm_management_system/features/presiding_concern/di/presiding_concern_module.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_action_outcome.dart';
import 'package:evm_management_system/features/presiding_concern/domain/entities/presiding_entities.dart';
import 'package:evm_management_system/features/presiding_concern/presentation/controllers/presiding_party_controller.dart';
import 'package:evm_management_system/features/presiding_concern/presentation/widgets/presiding_milestone_section.dart';
import 'package:evm_management_system/features/presiding_concern/presentation/widgets/presiding_party_details_sheet.dart';
import 'package:evm_management_system/features/presiding_concern/presentation/widgets/presiding_party_mandatory_banner.dart';
import 'package:evm_management_system/features/presiding_concern/presentation/widgets/presiding_session_scaffold.dart';
import 'package:evm_management_system/localization/locale_keys.dart';
import 'package:evm_management_system/shared/design_system/design_system.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide Trans;

/// Presiding-officer election-day milestone dashboard.
class PresidingDashboardScreen extends StatelessWidget {
  const PresidingDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PresidingSessionScaffold(
      builder: (BuildContext context, PresidingSession session) {
        return _DashboardBody(session: session);
      },
    );
  }
}

class _DashboardBody extends StatefulWidget {
  const _DashboardBody({required this.session});

  final PresidingSession session;

  @override
  State<_DashboardBody> createState() => _DashboardBodyState();
}

class _DashboardBodyState extends State<_DashboardBody> {
  PresidingPartyController get _partyCtrl =>
      Get.find<PresidingPartyController>();

  @override
  void initState() {
    super.initState();
    unawaited(_partyCtrl.refresh());
  }

  Future<void> _openPartySheet() async {
    await showPresidingPartyDetailsSheet(
      context,
      onCompleted: () => unawaited(_partyCtrl.refresh()),
    );
  }

  Future<void> _onRefresh(BuildContext context) async {
    final PresidingDashboardController controller =
        Get.find<PresidingDashboardController>();
    final bool ok = await controller.syncNow();
    if (!context.mounted) return;
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    if (!controller.isOnline.value) {
      messenger.showSnackBar(
        SnackBar(content: Text(LocaleKeys.presidingSyncOffline.tr())),
      );
      return;
    }
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? LocaleKeys.presidingSyncSuccess.tr()
              : LocaleKeys.presidingSyncFailed.tr(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final PresidingDashboardController controller =
        Get.find<PresidingDashboardController>();
    final String stationLabel =
        widget.session.pollingStationName.startsWith('presiding.')
        ? widget.session.pollingStationName.tr()
        : widget.session.pollingStationName;

    final Map<String, List<PresidingMilestone>> grouped =
        <String, List<PresidingMilestone>>{};
    for (final PresidingMilestone milestone in widget.session.milestones) {
      // मतदान समाप्त is submitted via 2–2 hourly finish — hide from section 4.
      if (milestone.id == PresidingMilestoneIds.pollEnd) continue;
      grouped.putIfAbsent(milestone.sectionId, () => <PresidingMilestone>[]);
      grouped[milestone.sectionId]!.add(milestone);
    }

    final List<_SectionMeta> sections = <_SectionMeta>[
      _SectionMeta(
        1,
        PresidingSectionIds.arrival,
        LocaleKeys.presidingSectionArrival.tr(),
      ),
      _SectionMeta(
        2,
        PresidingSectionIds.prePoll,
        LocaleKeys.presidingSectionPrePoll.tr(),
      ),
      _SectionMeta(
        3,
        PresidingSectionIds.duringPoll,
        LocaleKeys.presidingSectionDuringPoll.tr(),
      ),
      _SectionMeta(
        4,
        PresidingSectionIds.postPoll,
        LocaleKeys.presidingSectionPostPoll.tr(),
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        AppGradientHeader(
          centerTitle: true,
          title: LocaleKeys.presidingOfficerTitle.tr(),
          subtitle: LocaleKeys.presidingPollingStation.tr(
            args: <String>[
              widget.session.pollingStationCode,
              stationLabel,
            ],
          ),
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
          leading: AppCircleBackButton(onTap: () => Get.back<void>()),
          trailing: Obx(() {
            final bool syncing = controller.isSyncing.value;
            final bool online = controller.isOnline.value;
            return IconButton(
              tooltip: LocaleKeys.presidingSyncRefresh.tr(),
              onPressed: syncing ? null : () => _onRefresh(context),
              icon: syncing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Icon(
                      online ? Icons.sync_rounded : Icons.cloud_off_rounded,
                      color: Colors.white,
                    ),
            );
          }),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  LocaleKeys.presidingEnterInfo.tr(),
                  style: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.slate700,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Obx(() {
                final bool online = controller.isOnline.value;
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: online
                        ? const Color(0xFFE8F5E9)
                        : const Color(0xFFFFF3E0),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    online
                        ? LocaleKeys.presidingOnline.tr()
                        : LocaleKeys.presidingOffline.tr(),
                    style: AppTextStyles.caption.copyWith(
                      color: online
                          ? const Color(0xFF2E7D32)
                          : const Color(0xFFE65100),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: PresidingPartyMandatoryBanner(onTap: _openPartySheet),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
            children: <Widget>[
              for (final _SectionMeta section in sections)
                if ((grouped[section.id] ?? <PresidingMilestone>[]).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(
                      bottom: MpSecTokens.sectionSpacing,
                    ),
                    child: PresidingMilestoneSectionCard(
                      index: section.index,
                      title: section.title,
                      milestones: grouped[section.id]!,
                      boothMapStationName:
                          section.index == 1 ? stationLabel : null,
                      isMilestoneEnabled: (PresidingMilestone milestone) =>
                          widget.session.isMilestoneActionEnabled(milestone.id),
                      onMilestoneTap: (PresidingMilestone milestone) async {
                        if (milestone.isCompleted) return;

                        final String? blockKey =
                            widget.session.milestoneActionBlockKey(milestone.id);
                        if (blockKey != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(blockKey.tr())),
                          );
                          return;
                        }

                        if (milestone.id ==
                            PresidingMilestoneIds.livePollInfo) {
                          await Get.toNamed<void>(
                            AppRoute.presidingLivePoll.path,
                          );
                          return;
                        }

                        if (milestone.opensTurnout) {
                          await Get.toNamed<void>(
                            AppRoute.presidingTurnout.path,
                          );
                          return;
                        }

                        final PresidingActionOutcome outcome = await controller
                            .completeMilestone(milestone.id);
                        if (!context.mounted) return;
                        final String? msg = outcome.message;
                        if (msg == LocaleKeys.presidingPollStartBefore7Am ||
                            msg == LocaleKeys.presidingReachStationFirst) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(msg!.tr())),
                          );
                          return;
                        }
                        if (outcome.alreadyRegistered) {
                          final String text = msg?.isNotEmpty ?? false
                              ? msg!
                              : LocaleKeys.presidingAlreadyRegistered.tr();
                          ScaffoldMessenger.of(
                            context,
                          ).showSnackBar(SnackBar(content: Text(text)));
                        }
                      },
                    ),
                  ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SectionMeta {
  const _SectionMeta(this.index, this.id, this.title);
  final int index;
  final String id;
  final String title;
}
